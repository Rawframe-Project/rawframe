symlink escape fixture
